<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" charset="<?php bloginfo('charset')?>"/>
<meta name="keywords" content="blue smoothie, free template, blog theme" />
<meta name="description" content="<?php bloginfo('description')?>" />
<link href="<?php bloginfo('stylesheet_uri')?>" rel="stylesheet" type="text/css" />
<?php wp_head();?>

<script language="javascript" type="text/javascript">
function clearText(field)
{
    if (field.defaultValue == field.value) field.value = '';
    else if (field.value == '') field.value = field.defaultValue;
}
</script>

</head>
<body id="sub" <?php body_class();?>>

<div id="templatemo_wrapper">
	<div id="templatmeo_header">
    	<div id="site_title"><h1><img style="width:235px;height:65px;" src="<?php global $blue_theme; echo $blue_theme['logo_upload']['url'];?>"/></h1></div>
        <div id="templatemo_menu">
            <?php if(function_exists('wp_nav_menu')){
				wp_nav_menu(array(
				'theme_location'=>'main_menu'
				));
			}?> 	
        </div> <!-- end of templatemo_menu -->
    </div> <!-- end of header -->
    translate>
	<?php echo do_shortcode('[google-translator]'); ?>
