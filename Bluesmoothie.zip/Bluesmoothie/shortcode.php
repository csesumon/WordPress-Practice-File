<?php

function shortcode_function($atts,$content){
	
	$shortcodes = shortcode_atts(array(
	'cl'=>'left',
	),$atts);
	return "<h1 align='".$shortcodes['cl']."'>".$content."</h1>";
}
add_shortcode('image','shortcode_function');

?>
<?php
function big_shortcode($atts,$content){
	ob_start();?>
	<?php
	$number_of_post = shortcode_atts(array(
	'number'=>3
	),$atts);
	?>
	<?php $update = new Wp_Query(array(
				'post_type'=>'post',
				'posts_per_page'=>$number_of_post['number']
				));?>
				 <?php while($update->have_posts()):$update->the_post();?>
                <div class="sb_news_box update_img">
                    <?php the_post_thumbnail();?>
                    <div class="news_date"><?php the_time('F d Y');?></div>
                    <h6><a href="<?php the_permalink();?>"><?php the_title();?></a></h6>
                    <div class="cleaner"></div>
                </div>
               <?php endwhile;?>
<?php
$variable = ob_get_clean();
return $variable;
}
add_shortcode('big','big_shortcode');

?>