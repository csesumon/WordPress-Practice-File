<?php
/*
Template Name:Contact
*/;
?>
<?php get_header();?>
    
     <div id="templatemo_middle_sub">
        <div id="mid_title">Contact Information</div>
        <p>In vel sapien turpis, vel semper felis. In augue eros, semper sed interdum vel, eleifend nec tellus. Pellentesque lobortis aliquet sapien suscipit imperdiet. Cras egestas quam nec tortor ultricies dictum. Suspendisse vulputate, nibh at posuere dignissim, leo dolor sodales orci, ac sagittis erat nisi sit amet tellus. </p>
	</div> <!-- end of middle -->
    
     <div id="templatemo_main">
        <div class="col_w450 float_l">
            <div id="contact_form">
        
                <h2>Quick Contact Form</h2>
                <?php $update = new Wp_Query(array(
				'post_type'=>'page',
				'posts_per_page'=>4
				));?>
				 <?php while($update->have_posts()):$update->the_post();?>
                <div class="sb_news_box update_img">
                    <h6><?php the_content();?></h6>
                    <div class="cleaner"></div>
                </div>
               <?php endwhile;?>
            </div> 
        </div>
            
        <div class="col_w450 float_r">
            
            <div id="map">
			
			</div>                
            <div class="cleaner h30"></div>
            
            <?php dynamic_sidebar('mailing_address');?>
        </div>    	
    	
    	<div class="cleaner"></div>
    </div> <!-- end of templatemo_main -->
</div> <!-- end of wrapper -->
<?php get_footer();?>