<?php

function our_new_meta_box(array $ourmetabox){
$pre = _blue_;
	$ourmetabox[] = array(
		'id'=>'our-metabox',
		'title'=>'What is your favorite color?',
		'object_types'=>array(post),
		'fields'=>array(
		array(
			'id'=>$pre.'custom-color',
			'name'=>'Please enter your color',
			'type'=>'text',
			),
			array(
			'id'=>$pre.'custom-text_email',
			'name'=>'Please enter your email',
			'type'=>'text_email',
			),
			array(
			'id'=>$pre.'custom-colorpicker',
			'name'=>'Please enter your color',
			'type'=>'colorpicker',
			),
			array(
			'id'=>$pre.'custom-radio',
			'name'=>'Please enter your gender',
			'type'=>'radio',
			'options'=>array(
			'1'=>'Male',
			'2'=>'Female',
			)
			),
			array(
			'id'=>$pre.'custom-select',
			'name'=>'Please select your category',
			'type'=>'select',
			'options'=>array(
			'Category 1'=>'cat',
			'Category 2'=>'mat',
			'Category 3'=>'bat',
			)
			),
			array(
			'id'=>$pre.'custom-taxonomy_select',
			'name'=>'Please select your category',
			'type'=>'taxonomy_select',
			'taxonomy'=>'category'
			),
			array(
			'id'=>$pre.'custom-multicheck',
			'name'=>'Please check any one',
			'type'=>'multicheck',
			'options'=>array(
			'1'=>'One',
			'2'=>'two',
			'3'=>'Three',
			)
			),
			array(
			'id'=>$pre.'custom-wysiwyg',
			'name'=>'Please enter your content',
			'type'=>'wysiwyg',
			'options'=>array(
			'textarea_rows' => get_option('default_post_edit_rows', 10),
			)
			),
			array(
			'id'=>$pre.'custom-file',
			'name'=>'Please upload your file',
			'type'=>'file',
			),
			array(
			'id'=>$pre.'custom-file_list',
			'name'=>'Please upload multiple file',
			'type'=>'file_list',
			),
			array(
			'id'=>$pre.'custom-oembed',
			'name'=>'Please embed any file',
			'type'=>'oembed',
			),
		)
	);
	return $ourmetabox;

}
add_filter('cmb2_meta_boxes','our_new_meta_box');


?>