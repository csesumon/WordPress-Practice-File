<?php
/*
Template Name:Gallery
*/;
?>
<?php get_header();?>
    
    <div id="templatemo_middle_sub">
        <div id="mid_title">Our Gallery</div>
        <p>Suspendisse potenti. Aenean tellus odio, blandit at egestas a, laoreet et tellus. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec vel augue id sem sagittis mollis tempus sit amet erat. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aenean ut ipsum dolor.</p>
	</div> <!-- end of middle -->
    
     <div id="templatemo_main">
        <?php $gallery_item =  new Wp_Query(array(
		'post_type'=>'gallery_id',
		'posts_per_page'=>3,
		'pagination'=>true
		));?>
        <div id="gallery">
            <ul><?php while($gallery_item->have_posts()):$gallery_item->the_post();?>
                <li class="rm_col">
                    <a href="#"><span></span>
                       <?php the_post_thumbnail();?>
                    </a>
                    <em><?php the_title();?></em>
                </li> 
				
		<?php endwhile;?>				
         	</ul>
            
            <div class="cleaner"></div>
       </div>
       
  </div> <!-- end of templatemo_main -->
</div> <!-- end of wrapper -->

<?php get_footer();?>