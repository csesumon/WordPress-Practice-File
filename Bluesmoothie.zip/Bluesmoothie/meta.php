<?php 
/*template Name: Meta*/
?>
<?php get_header();?>
    
    <div id="templatemo_middle_sub">
        <div id="mid_title">
           	Our Blog Posts
        </div>
        <p>Fusce in tellus et arcu elementum commodo. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Sed viverra mollis mauris eget volutpat. Etiam lacinia imperdiet libero, id euismod velit laoreet ut. Nam metus purus, varius sed dapibus id, porta ac velit. Quisque volutpat lobortis urna in adipiscing. </p>
	</div> <!-- end of middle -->
    
    <div id="templatemo_main">
	<?php 
		$meta_post = new Wp_Query(array(
		'post_type'=>'post',
		'posts_per_page'=>1
		));
	?>
	<?php $pre = _blue_;?>
	<?php while($meta_post->have_posts()):$meta_post->the_post();?>
        <div class="post_box">
            <h2><?php the_title();?></h2>
            <div class="image_frame"><span></span><?php the_post_thumbnail();?></div>
            <p><span class="cat"><?php the_time('F d Y');?> Posted by <a href="#"><?php the_author();?></a>,</span> | <a href="#"><?php comments_popup_link('No Comment','1 Comment','% Comment','style_class')?></a></p>
            <p><?php read_more(20);?></p>	
            <a class="more float_l" href="<?php the_permalink();?>">More</a>
            <div class="cleaner"></div>
        </div>
		<p>Color is:<?php echo get_post_meta(get_the_ID(),$pre.'custom-color',true);?></p>
		<p>Email is:<?php echo get_post_meta(get_the_ID(),$pre.'custom-text_email',true);?></p>
		<?php
		$cl = get_post_meta(get_the_ID(),$pre.'custom-colorpicker',true);
		?>
		<h4 style='color:<?php echo $cl;?>'>Color</h4>
		
		<?php
		$rd = get_post_meta(get_the_ID(),$pre.'custom-radio',true);
		?>
		<p>
			<?php if($rd==1){
				echo "You are Male";
			}else{
				echo "You are Female";
			}?>
		</p>
		<p>Category is:<?php echo get_post_meta(get_the_ID(),$pre.'custom-select',true);?></p>
		<p>The Selected Category is:
		<?php
			$taxcat = get_post_meta(get_the_ID(),$pre.'custom-taxonomy_select',true);
			echo $taxcat[1];
		?>
		</p>
		<p>Check any one Of this list:<?php $mul = get_post_meta(get_the_ID(),$pre.'custom-multicheck',true);
			foreach($mul as $value){
				echo $value;
			}
		
		?></p>
		<p>Content:<?php echo get_post_meta(get_the_ID(),$pre.'custom-wysiwyg',true);?></p>
		<?php $up =  get_post_meta(get_the_ID(),$pre.'custom-file',true);?>
		<p>upload file:<img src="<?php echo $up;?>" width="100px" height="100px"/></p>
		<p>Upload multiple file:</p>
		<?php $up =  get_post_meta(get_the_ID(),$pre.'custom-file_list',true);
			foreach($up as $multiple_image){?>
				<p><img src="<?php echo $multiple_image;?>" width="100px" height="100px"/></p>
			<?php  }?>
		
		<p>Embed file is:</p>
		<?php
			$em = get_post_meta(get_the_ID(),$pre.'custom-oembed',true);
		?>
		
		<iframe width="560" height="315" src="<?php echo $em;?>" frameborder="0" allowfullscreen></iframe>
	<?php endwhile;?>
		
    </div> <!-- end of templatemo_main -->
</div> <!-- end of wrapper -->
<?php get_footer();?>