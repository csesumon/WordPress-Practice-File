<?php
/*Template Name: About*/
?>

<?php get_header();?>
    <!-- | | |   w w w . t e m p l a t e m o . c o m   | | | -->
    <div id="templatemo_middle_sub">
        <div id="mid_title">About Us</div>
        <p>Curabitur scelerisque accumsan mauris, in lacinia massa consectetur sit amet. Maecenas in tincidunt metus. Quisque vitae lectus in risus faucibus vulputate. Quisque rutrum interdum tellus volutpat interdum. Proin iaculis dui vel lorem vulputate venenatis. Quisque at mi quis leo semper ullamcorper. Fusce et pellentesque nisi.</p>
	</div> <!-- end of middle -->
    
     <div id="templatemo_main">
        <div class="col_w600 float_l">
        	
            <h2>Who We Are</h2>
       
             <p><em>Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Praesent aliquam velit a magna sodales quis elementum ipsum auctor.</em></p>
            <p>In ac libero urna. Suspendisse sed <a href="#">odio ut mi</a> auctor blandit. Duis luctus nulla metus, a vulputate mauris. Integer sed nisi sapien, ut gravida mauris. Nam et tellus libero. Cras purus libero, dapibus nec risus. Ut interdum mi sit amet magna feugiat auctor.</p>
            <div class="h30"></div>
            <div class="image_frame image_fr"><span></span><img src="<?php echo esc_url(get_template_directory_uri());?>/images/templatemo_image_01.jpg" alt="Image 01" /></div>
            <h6>Duis pellentesque est non lacus aliquam</h6>
            <p>Praesent volutpat dolor at nulla egestas in vestibulum mauris lacinia. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Mauris eu lorem nec enim sollicitudin sodales condimentum ut arcu.</p>
        </div>
        <div class="col_w300 float_r">
        
            <h2>Testimonial</h2>
            <blockquote>
            <p>Fusce nec felis id lacus sollicitudin vulputate. Proin tincidunt, arcu id pellentesque accumsan, neque dolor imperdiet ligula, quis viverra tellus nulla a odio. Curabitur vitae enim risus, at placerat turpis. Mauris feugiat suscipit tempus fringilla, felis in velit. Ut ut aliquet felis.</p>
            
            <cite>Valenti - <span>Designer</span></cite>
            </blockquote>
        
        </div>    
        <div class="cleaner"></div>	
    </div> <!-- end of templatemo_main -->
</div> <!-- end of wrapper -->
<?php get_footer();?>