<?php
function add_our_meta_box(){
add_meta_box(
'color_id',
'Add your favorite color',
'callbackfunction',
array('slider_id','page'),
'normal'
);
}
add_action('add_meta_boxes','add_our_meta_box');

function callbackfunction($post){?>
<label for="color">What is your favorite color?</label>
<p><input type="text" name="color_name" id="color" class="widefat" value="<?php echo get_post_meta($post->ID,'color_name',true);?>"/></p>
<?php }
function update_our_meta_box($postid){
update_post_meta($postid,'color_name',$_POST['color_name']);
}
add_action('save_post','update_our_meta_box');
 ?>
