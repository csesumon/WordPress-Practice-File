<?php
/*
Template Name: Home
*/
?>

<?php get_header();?>
    
    <div id="templatemo_middle">
    	<div id="mid_slider"><span></span>
        	<div id="slider1" class="sliderwrapper">
			<?php $slider = new Wp_Query(array(
			'posts_per_page'=>4,
			'post_type'=>'slider_id'
			));?>
			<?php while($slider->have_posts()):$slider->the_post();?>
                <div class="contentdiv slider_img">
                    <?php the_post_thumbnail();?>
                </div>
			<?php endwhile;?>
            </div>
            
            <div id="paginate-slider1" class="pagination">
            
      </div>
            
            <script type="text/javascript">
            
            featuredcontentslider.init({
                id: "slider1",  //id of main slider DIV
                contentsource: ["inline", ""],  //Valid values: ["inline", ""] or ["ajax", "path_to_file"]
                toc: "#increment",  //Valid values: "#increment", "markup", ["label1", "label2", etc]
                nextprev: ["", ""],  //labels for "prev" and "next" links. Set to "" to hide.
                revealtype: "click", //Behavior of pagination links to reveal the slides: "click" or "mouseover"
                enablefade: [true, 0.4],  //[true/false, fadedegree]
                autorotate: [true, 2000],  //[true/false, pausetime]
                onChange: function(previndex, curindex){  //event handler fired whenever script changes slide
                    //previndex holds index of last slide viewed b4 current (1=1st slide, 2nd=2nd etc)
                    //curindex holds index of currently shown slide (1=1st slide, 2nd=2nd etc)
                }
            })
            
            </script>
        </div>
        <div id="mid_left">
            <div id="mid_title">Web Design Company</div>
            <p>Aliquam in odio ut ipsum mollis facilisis. Integer est sem, dignissim quis auctor vel, dapibus vel massa. Curabitur vulputate ligula vel mi semper tempus. Vivamus volutpat, elit non tempor vehicula.</p>
            <div id="learn_more"><a href="#">Learn More</a></div>
	  </div>
        <div class="cleaner"></div>
	</div> <!-- end of middle -->
    
     <div id="templatemo_main">
        <div id="templatemo_content">
        
        	<div class="col_allw300">
            	<h2>Products</h2>
                <p><em>Curabitur interdum, nulla sed posuere gravida, urna est lobortis odio, eu mauris lorem eu nisl.</em></p>
                <p>Aliquam in odio ut ipsum mollis facilisis. Integer est sem, dapibus vel massa. Curabitur vulputate ligula vel mi semper tempus. Vivamus volutpat, elit non tempor vehicula. Integer est sem, dignissim quis auctor vel, dapibus vel.</p>
                            
                <ul class="templatemo_list">
                  	<li>Sed nec eros egestas nisl </li>
                    <li>Morbi sed nulla ac est cursus </li>
                    <li>Curabitur ullamcorper nibh </li>
                    <li>Pellentesque adipiscing </li>    
                    <li>Aliquam eget nibh nulla</li>    
                    <li>Mauris imperdiet mollis nibh </li>  
                    <li>Sed vel diam eget enim</li>   
                    <li>Vestibulum at tellus mauris</li           
              ></ul>
                <div class="cleaner"></div>
                <a href="#" class="more">Read more</a>
            </div>
			
			<div class="col_allw300">
            	 <h2>Updates</h2>
				<?php $update = new Wp_Query(array(
				'post_type'=>'post',
				'posts_per_page'=>4
				));?>
				 <?php while($update->have_posts()):$update->the_post();?>
                <div class="sb_news_box update_img">
                    <?php the_post_thumbnail();?>
                    <div class="news_date"><?php the_time('F d Y');?></div>
                    <h6><a href="<?php the_permalink();?>"><?php the_title();?></a></h6>
                    <div class="cleaner"></div>
                </div>
               <?php endwhile;?>
                <a href="#" class="more">Read All</a>   
            </div>
            
            <div class="col_allw300 col_last">
            	<h2>Featured Sites</h2>
                <div class="fp_lw_box">
                <div class="image_frame"><span></span><img src="<?php echo esc_url(get_template_directory_uri())?>/images/templatemo_image_01.jpg" alt="Image 01" /></div
                ><p><em>Morbi sed nulla ac est cursus suscipit ac lectus.</em></p>
				</div>
                <div class="fp_lw_box">
                <div class="image_frame"><span></span><img src="<?php echo esc_url(get_template_directory_uri())?>/images/templatemo_image_02.jpg" alt="Image 02" /></div
                ><p><em>Proin iaculis dui vel lorem vulputate venenatis.</em></p>
				</div>
                <div class="cleaner"></div>
                <a href="#" class="more">Read more</a>
            </div>
            <div class="cleaner"></div>
			
	<?php
	$left_cat = get_the_category_by_id($blue_theme['category_select_left']);
	$national = new Wp_Query(array(
	'posts_per_page'=>4,
	'post_type'=>'post',
	'category_name'=>$left_cat
	));?>
	<?php while($national->have_posts()):$national->the_post();?>
			<div class="col_allw300">
            	 <h2>National</h2>
				 <h2><?php the_title();?></h2>
            </div>
			<?php endwhile;
			?>
			
	<?php 
	$right_cat = get_the_category_by_id($blue_theme['category_select_right']);
	$international = new Wp_Query(array(
	'posts_per_page'=>4,
	'post_type'=>'post',
	'category_name'=>$right_cat
	));?>
	<?php while($international->have_posts()):$international->the_post();?>
			<div class="col_allw300">
            	 <h2>International</h2>
            	 <h2><?php the_title();?></h2>
            </div>
			<?php endwhile;?>
        </div> <!-- end of templatemo_content -->
    </div> <!-- end of templatemo_main -->
</div> <!-- end of wrapper -->

<?php get_footer();?>