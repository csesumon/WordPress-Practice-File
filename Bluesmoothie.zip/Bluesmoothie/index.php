<?php
/*
Template Name:Blog
*/;
?>
<?php get_header();?>
    
    <div id="templatemo_middle_sub">
        <div id="mid_title">
           	Our Blog Posts
        </div>
        <p>Fusce in tellus et arcu elementum commodo. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Sed viverra mollis mauris eget volutpat. Etiam lacinia imperdiet libero, id euismod velit laoreet ut. Nam metus purus, varius sed dapibus id, porta ac velit. Quisque volutpat lobortis urna in adipiscing. </p>
	</div> <!-- end of middle -->
    
    <div id="templatemo_main">
	<?php while(have_posts()):the_post();?>
        <div class="post_box">
            <h2><?php the_title();?></h2>
            <div class="image_frame"><span></span><?php the_post_thumbnail();?></div>
            <p><span class="cat"><?php the_time('F d Y');?> Posted by <a href="#"><?php the_author();?></a>,</span> | <a href="#"><?php comments_popup_link('No Comment','1 Comment','% Comment','style_class')?></a></p>
            <p><?php read_more(20);?></p>	
            <a class="more float_l" href="<?php the_permalink();?>">More</a>
            <div class="cleaner"></div>
        </div>
		<?php endwhile;?>
		
    </div> <!-- end of templatemo_main -->
</div> <!-- end of wrapper -->
<?php get_footer();?>