<?php get_header();?>
  <?php while(have_posts()):the_post()?>
  <?php the_title();?>
  <?php the_content();?>
  <?php the_post_thumbnail();?> 
  <?php endwhile;?>
 <h2 style='color:red'><?php echo get_post_meta($post->ID,'color_name',true);?></h2>
<?php get_footer();?>