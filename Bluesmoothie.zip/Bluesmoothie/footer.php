
<div id="templatemo_footer_wrapper">
    <div id="templatemo_footer">
    
    	<?php dynamic_sidebar('footer_widgets');?>
    
    </div> <!-- end of templatemo_footer -->
     <div class="cleaner"></div>
</div>


<div id="templatemo_copyright_wrapper">
    <div id="templatemo_copyright">
    	
           <?php global $blue_theme;
		   echo $blue_theme['copyright'];
		   ?>
        
    </div> <!-- end of templatemo_footer -->
</div>
<?php wp_footer();?>
</body>
</html>