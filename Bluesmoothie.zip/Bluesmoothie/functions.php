<?php
function default_blue_smooithe(){
add_theme_support('title-tag');	
add_theme_support('custom-header');	
add_theme_support('custom-background');	
add_theme_support('post-thumbnails');	
	
load_theme_textdomain('blue',get_template_directory().'/languages');	
if(function_exists('register_nav_menu')){
	register_nav_menu('main_menu',__('Main Menu','blue'));	
}	
function read_more($limit){
	$post_content = explode(' ',get_the_content());
	$less_content = array_slice($post_content,0,$limit);
	echo implode(' ',$less_content);	
}
register_post_type('slider_id',array(
'labels'=>array(
'name'=>__('Slider','blue'),
'add_new_item'=>__('Add New Slider','blue'),
'remove_featured_image'=>'Remove Slider Image',
'set_featured_image'=>'Set Slider Image'
),
'public'=>true,
'supports'=>'thumbnail',
'menu_position'=>15,
'menu_icon'=>get_template_directory_uri().'/images/slider.png',
));

register_post_type('gallery_id',array(
'labels'=>array(
'name'=>'Gallery',
'add_new_item'=>'Add New Gallery',
'remove_featured_image'=>'Remove Gallery Image',
'set_featured_image'=>'Set Gallery Image'
),
'public'=>true,
'supports'=>array('title','thumbnail'),
'menu_icon'=>'dashicons-format-gallery',
));
	add_filter('widget_text','do_shortcode');
}
add_action('after_setup_theme','default_blue_smooithe');


function blue_widget(){
	register_sidebar(array(
	'id'=>'mailing_address',
	'name'=>'Mailing Address',
	'description'=>'if we have faced any problem please contact us for your help',
	'before_widget'=>'<div class="col_w450 float_r">',
	'after_widget'=>'</div>',
	'before_title'=>'<h4>',
	'after_title'=>'</h4>',
	));
	
	register_sidebar(array(
	'id'=>'footer_widgets',
	'name'=>'Footer Widgets',
	'description'=>'Footer part wiidgets if you can change this content',
	'before_widget'=>'<div class="col_allw300 col_last">',
	'after_widget'=>'</div></ul>',
	'before_title'=>'<h4>',
	'after_title'=>'</h4><ul class="footer_list">',
	));
}
add_action('widgets_init','blue_widget');

function css_js(){
	
	wp_register_style('templatemo_style',get_template_directory_uri().'/css/templatemo_style.css');
	wp_register_style('contentslider',get_template_directory_uri().'/css/contentslider.css');
	wp_register_script('contentslider',get_template_directory_uri().'/scripts/contentslider.js');
	
	
	
	wp_enqueue_style('templatemo_style');
	wp_enqueue_style('contentslider');
	wp_enqueue_script('contentslider');
	
	
}
add_action('wp_enqueue_scripts','css_js');

require_once "inc/ReduxCore/framework.php";
require_once "inc/sample/config.php";
require_once "shortcode.php";
require_once "custom_metabox.php";
require_once "metabox/init.php";
require_once "metabox/metabox_functions.php";












?>